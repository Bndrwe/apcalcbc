// Cloudflare Worker — OpenRouter Proxy
//
// SETUP (takes 2 min):
// 1. Go to dash.cloudflare.com → Workers & Pages → Create Worker
// 2. Paste this entire file, click Deploy
// 3. In your Worker → Settings → Variables → Add variable:
//      Name:  OPENROUTER_KEY
//      Value: your OpenRouter key  ← click Encrypt!
// 4. Copy your Worker URL (e.g. https://apcalc-proxy.yourname.workers.dev)
// 5. In index.html, replace PROXY_URL with that Worker URL
// 6. Replace YOUR_PAGES_DOMAIN below with your actual Cloudflare Pages domain

const ALLOWED_ORIGINS = [
  'https://YOUR_PAGES_DOMAIN.pages.dev',  // ← your Cloudflare Pages URL
  'http://localhost',
  'http://127.0.0.1',
];

export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';
    const corsOrigin = ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];

    const cors = {
      'Access-Control-Allow-Origin': corsOrigin,
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    };

    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: cors });
    }

    if (request.method !== 'POST') {
      return new Response('Method not allowed', { status: 405, headers: cors });
    }

    try {
      const body = await request.json();

      const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${env.OPENROUTER_KEY}`,
        },
        body: JSON.stringify(body),
      });

      const data = await response.json();

      return new Response(JSON.stringify(data), {
        status: response.status,
        headers: { 'Content-Type': 'application/json', ...cors },
      });

    } catch (err) {
      return new Response(JSON.stringify({ error: err.message }), {
        status: 500,
        headers: { 'Content-Type': 'application/json', ...cors },
      });
    }
  }
};
