// Cloudflare Pages Function — /functions/api.js
// This file goes in a "functions" folder in the root of your repo.
// Add your key in Cloudflare Pages → Settings → Environment Variables:
//   Variable name: OPENROUTER_KEY
//   Value: your OpenRouter key  ← stored as secret, never in your repo

export async function onRequestPost({ request, env }) {
  try {
    const body = await request.json();

    const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${env.OPENROUTER_KEY}`,
      },
      body: JSON.stringify(body),
    });

    const data = await response.json();

    return new Response(JSON.stringify(data), {
      status: response.status,
      headers: { 'Content-Type': 'application/json' },
    });

  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}
